/*=============================================
Title: setup_business_data

Usage: 

Author:		Rice, Newel

--
Create date: 2020-OCT-17
--
Description:	setup_business_data
				is used to setup business data for the Lab/Demo environment

Requires:	none
--
--
Optional:
--
WARNING: This is a destructive script - review before using - USE AT YOUR OWN RISK!
--
Copyright (C) 2020 - Sirius Solutions, Inc.
All Rights Reserved
--
Version: 0.0.1.000
Revision History:


0.0.1.000 Original
=============================================*/
--Setup the context
USE ROLE SYSADMIN;
USE WAREHOUSE XSMALL;
USE ID_DEV;
USE SCHEMA public;

--Get some data
--We only want to work with data from the USA C_NATIONKEY 24 = US
CREATE OR REPLACE TABLE PUBLIC.CUSTOMER AS SELECT * FROM "SNOWFLAKE_SAMPLE_DATA"."TPCH_SF10"."CUSTOMER"
WHERE C_NATIONKEY = 24;
CREATE  OR REPLACE TABLE PUBLIC.LINEITEM AS SELECT * FROM "SNOWFLAKE_SAMPLE_DATA"."TPCH_SF10"."LINEITEM";
CREATE  OR REPLACE TABLE PUBLIC.NATION   AS SELECT * FROM "SNOWFLAKE_SAMPLE_DATA"."TPCH_SF10"."NATION"  ;
CREATE  OR REPLACE TABLE PUBLIC.ORDERS   AS SELECT * FROM "SNOWFLAKE_SAMPLE_DATA"."TPCH_SF10"."ORDERS"  ;
CREATE  OR REPLACE TABLE PUBLIC.PART     AS SELECT * FROM "SNOWFLAKE_SAMPLE_DATA"."TPCH_SF10"."PART"    ;
CREATE  OR REPLACE TABLE PUBLIC.PARTSUPP AS SELECT * FROM "SNOWFLAKE_SAMPLE_DATA"."TPCH_SF10"."PARTSUPP";
CREATE  OR REPLACE TABLE PUBLIC.REGION   AS SELECT * FROM "SNOWFLAKE_SAMPLE_DATA"."TPCH_SF10"."REGION"  ;
CREATE  OR REPLACE TABLE PUBLIC.SUPPLIER AS SELECT * FROM "SNOWFLAKE_SAMPLE_DATA"."TPCH_SF10"."SUPPLIER";

--We don't have good address data in the sample data so we're going to make something up to work from
CREATE OR REPLACE TRANSIENT TABLE PUBLIC.CUSTOMER_ADDRESS  AS SELECT ROW_NUMBER() OVER (ORDER BY CA_ADDRESS_ID DESC) AS CA_CUSTKEY, * FROM "SNOWFLAKE_SAMPLE_DATA"."TPCDS_SF10TCL"."CUSTOMER_ADDRESS" WHERE CA_COUNTRY IS NOT NULL;

--We need to increase the size of the address column to accomodate an address with CSZ
ALTER TABLE IF EXISTS PUBLIC.CUSTOMER ALTER COLUMN C_ADDRESS VARCHAR(256);

--Assign a US style address to customer and supplier - this will be used to create a solution in a later lab - some with suite and some without suite
--No suite
UPDATE CUSTOMER SET C_ADDRESS =
       (CA_STREET_NUMBER || ' ' || 
        CA_STREET_NAME   || ' ' ||
        CA_STREET_TYPE   || ' ' ||
        CA_CITY          || ' ' ||
        CA_STATE         || ' ' ||
        CA_ZIP
       )
FROM CUSTOMER_ADDRESS
WHERE CUSTOMER.C_CUSTKEY = CUSTOMER_ADDRESS.CA_CUSTKEY
AND C_CUSTKEY > 60000;

--Suite
UPDATE CUSTOMER SET C_ADDRESS =
       (CA_STREET_NUMBER || ' ' || 
        CA_STREET_NAME   || ' ' ||
        CA_STREET_TYPE   || ' ' ||
        CA_SUITE_NUMBER  || ' ' ||
        CA_CITY          || ' ' ||
        CA_STATE         || ' ' ||
        CA_ZIP
       )
FROM CUSTOMER_ADDRESS
WHERE CUSTOMER.C_CUSTKEY = CUSTOMER_ADDRESS.CA_CUSTKEY
AND C_CUSTKEY < 60000;

-- we no longer need the CUSTOMER_ADDRESS TABLE
DROP TABLE CUSTOMER_ADDRESS;

--Get the delta between the max order date and today's data
SET(CHANGEDAYS) = (SELECT CURRENT_DATE() - MAX(ORDERS.O_ORDERDATE) FROM ORDERS);

--Update the order date so that it is more recent
UPDATE ORDERS SET O_ORDERDATE = O_ORDERDATE + ($CHANGEDAYS - 1);