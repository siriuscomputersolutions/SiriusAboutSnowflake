/*=============================================
Title: createrole_weather

Usage: 

Author:		Rice, Newel

--
Create date: 2020-OCT-17
--
Description:	createrole_weather
				is used to setup a role
                for access to the shared weather data

Requires:	none
--
--
Optional:
--
WARNING: This is a destructive script - review before using - USE AT YOUR OWN RISK!
--
Copyright (C) 2020 - Sirius Solutions, Inc.
All Rights Reserved
--
Version: 0.0.1.000
Revision History:


0.0.1.000 Original
=============================================*/
--Setup the context
USE ROLE ACCOUNTADMIN;

--create weather role
CREATE ROLE "WEATHER";
GRANT ROLE "WEATHER" TO ROLE "SYSADMIN";