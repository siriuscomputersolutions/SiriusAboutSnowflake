/*=============================================
Title: source_weatherdata

Usage: 

Author:		Rice, Newel

--
Create date: 2020-OCT-17
--
Description:	source_weatherdata
				is used to setup weather data for the Lab/Demo environment

Requires:	none
--
--
Optional:
--
WARNING: This is a destructive script - review before using - USE AT YOUR OWN RISK!
--
Copyright (C) 2020 - Sirius Solutions, Inc.
All Rights Reserved
--
Version: 0.0.1.000
Revision History:


0.0.1.000 Original
=============================================*/
USE ROLE SYSADMIN;
USE WAREHOUSE XSMALL;
USE ID_DEV;
USE SCHEMA public;

--Where are we getting our Weather Date from? The Data Market Place
--We have some problems here. The Weather data is at the grain of city but our analysis
--requirements are at the grain of state. We need to come up with a weather value at
--at the grain of state.
--The state value is spelled out but in the rest of our data the state is recorded as its
--two letter abbreviation. We need to include a translation of STATE name to ST abbreviation
CREATE  OR REPLACE TABLE PUBLIC.WEATHER_HISTORY_DAY AS 


WITH weather AS
(
   SELECT 
    POSTAL_CODE,
    COUNTRY,
    DATE_VALID_STD,
    DOY_STD,
    MIN_TEMPERATURE_AIR_2M_F,
    AVG_TEMPERATURE_AIR_2M_F,
    MAX_TEMPERATURE_AIR_2M_F,
    MIN_TEMPERATURE_WETBULB_2M_F,
    AVG_TEMPERATURE_WETBULB_2M_F,
    MAX_TEMPERATURE_WETBULB_2M_F,
    MIN_TEMPERATURE_DEWPOINT_2M_F,
    AVG_TEMPERATURE_DEWPOINT_2M_F,
    MAX_TEMPERATURE_DEWPOINT_2M_F,
    MIN_TEMPERATURE_FEELSLIKE_2M_F,
    AVG_TEMPERATURE_FEELSLIKE_2M_F,
    MAX_TEMPERATURE_FEELSLIKE_2M_F,
    MIN_TEMPERATURE_WINDCHILL_2M_F,
    AVG_TEMPERATURE_WINDCHILL_2M_F,
    MAX_TEMPERATURE_WINDCHILL_2M_F,
    MIN_TEMPERATURE_HEATINDEX_2M_F,
    AVG_TEMPERATURE_HEATINDEX_2M_F,
    MAX_TEMPERATURE_HEATINDEX_2M_F,
    MIN_HUMIDITY_RELATIVE_2M_PCT,
    AVG_HUMIDITY_RELATIVE_2M_PCT,
    MAX_HUMIDITY_RELATIVE_2M_PCT,
    MIN_HUMIDITY_SPECIFIC_2M_GPKG,
    AVG_HUMIDITY_SPECIFIC_2M_GPKG,
    MAX_HUMIDITY_SPECIFIC_2M_GPKG,
    MIN_PRESSURE_2M_MB,
    AVG_PRESSURE_2M_MB,
    MAX_PRESSURE_2M_MB,
    MIN_PRESSURE_TENDENCY_2M_MB,
    AVG_PRESSURE_TENDENCY_2M_MB,
    MAX_PRESSURE_TENDENCY_2M_MB,
    MIN_PRESSURE_MEAN_SEA_LEVEL_MB,
    AVG_PRESSURE_MEAN_SEA_LEVEL_MB,
    MAX_PRESSURE_MEAN_SEA_LEVEL_MB,
    MIN_WIND_SPEED_10M_MPH,
    AVG_WIND_SPEED_10M_MPH,
    MAX_WIND_SPEED_10M_MPH,
    AVG_WIND_DIRECTION_10M_DEG,
    MIN_WIND_SPEED_80M_MPH,
    AVG_WIND_SPEED_80M_MPH,
    MAX_WIND_SPEED_80M_MPH,
    AVG_WIND_DIRECTION_80M_DEG,
    MIN_WIND_SPEED_100M_MPH,
    AVG_WIND_SPEED_100M_MPH,
    MAX_WIND_SPEED_100M_MPH,
    AVG_WIND_DIRECTION_100M_DEG,
    TOT_PRECIPITATION_IN,
    TOT_SNOWFALL_IN,
    TOT_SNOWDEPTH_IN,
    MIN_CLOUD_COVER_TOT_PCT,
    AVG_CLOUD_COVER_TOT_PCT,
    MAX_CLOUD_COVER_TOT_PCT,
    MIN_RADIATION_SOLAR_TOTAL_WPM2,
    AVG_RADIATION_SOLAR_TOTAL_WPM2,
    MAX_RADIATION_SOLAR_TOTAL_WPM2,
    TOT_RADIATION_SOLAR_TOTAL_WPM2,
    CITY,
    STATE,
    STATEABRV,
    ROW_NUMBER() OVER (PARTITION BY State, date_valid_std ORDER BY date_valid_std DESC) AS rownum
 FROM "WEATHERSOURCE_AZURE_WESTUS2_WEATHER_SOURCE_SAMPLE_DAILY_CAPITALS_CA_EU_US"."PUBLIC"."HISTORY_DAY" wthr_hist
    INNER JOIN TRX_STATE_TO_ST s2s ON s2s.STATENAME = wthr_hist.state
)
--SELECT weather.* FROM weather;

SELECT 
    weather.POSTAL_CODE,
    weather.COUNTRY,
    weather.DATE_VALID_STD,
    weather.DOY_STD,
    weather.MIN_TEMPERATURE_AIR_2M_F,
    weather.AVG_TEMPERATURE_AIR_2M_F,
    weather.MAX_TEMPERATURE_AIR_2M_F,
    weather.MIN_TEMPERATURE_WETBULB_2M_F,
    weather.AVG_TEMPERATURE_WETBULB_2M_F,
    weather.MAX_TEMPERATURE_WETBULB_2M_F,
    weather.MIN_TEMPERATURE_DEWPOINT_2M_F,
    weather.AVG_TEMPERATURE_DEWPOINT_2M_F,
    weather.MAX_TEMPERATURE_DEWPOINT_2M_F,
    weather.MIN_TEMPERATURE_FEELSLIKE_2M_F,
    weather.AVG_TEMPERATURE_FEELSLIKE_2M_F,
    weather.MAX_TEMPERATURE_FEELSLIKE_2M_F,
    weather.MIN_TEMPERATURE_WINDCHILL_2M_F,
    weather.AVG_TEMPERATURE_WINDCHILL_2M_F,
    weather.MAX_TEMPERATURE_WINDCHILL_2M_F,
    weather.MIN_TEMPERATURE_HEATINDEX_2M_F,
    weather.AVG_TEMPERATURE_HEATINDEX_2M_F,
    weather.MAX_TEMPERATURE_HEATINDEX_2M_F,
    weather.MIN_HUMIDITY_RELATIVE_2M_PCT,
    weather.AVG_HUMIDITY_RELATIVE_2M_PCT,
    weather.MAX_HUMIDITY_RELATIVE_2M_PCT,
    weather.MIN_HUMIDITY_SPECIFIC_2M_GPKG,
    weather.AVG_HUMIDITY_SPECIFIC_2M_GPKG,
    weather.MAX_HUMIDITY_SPECIFIC_2M_GPKG,
    weather.MIN_PRESSURE_2M_MB,
    weather.AVG_PRESSURE_2M_MB,
    weather.MAX_PRESSURE_2M_MB,
    weather.MIN_PRESSURE_TENDENCY_2M_MB,
    weather.AVG_PRESSURE_TENDENCY_2M_MB,
    weather.MAX_PRESSURE_TENDENCY_2M_MB,
    weather.MIN_PRESSURE_MEAN_SEA_LEVEL_MB,
    weather.AVG_PRESSURE_MEAN_SEA_LEVEL_MB,
    weather.MAX_PRESSURE_MEAN_SEA_LEVEL_MB,
    weather.MIN_WIND_SPEED_10M_MPH,
    weather.AVG_WIND_SPEED_10M_MPH,
    weather.MAX_WIND_SPEED_10M_MPH,
    weather.AVG_WIND_DIRECTION_10M_DEG,
    weather.MIN_WIND_SPEED_80M_MPH,
    weather.AVG_WIND_SPEED_80M_MPH,
    weather.MAX_WIND_SPEED_80M_MPH,
    weather.AVG_WIND_DIRECTION_80M_DEG,
    weather.MIN_WIND_SPEED_100M_MPH,
    weather.AVG_WIND_SPEED_100M_MPH,
    weather.MAX_WIND_SPEED_100M_MPH,
    weather.AVG_WIND_DIRECTION_100M_DEG,
    weather.TOT_PRECIPITATION_IN,
    weather.TOT_SNOWFALL_IN,
    weather.TOT_SNOWDEPTH_IN,
    weather.MIN_CLOUD_COVER_TOT_PCT,
    weather.AVG_CLOUD_COVER_TOT_PCT,
    weather.MAX_CLOUD_COVER_TOT_PCT,
    weather.MIN_RADIATION_SOLAR_TOTAL_WPM2,
    weather.AVG_RADIATION_SOLAR_TOTAL_WPM2,
    weather.MAX_RADIATION_SOLAR_TOTAL_WPM2,
    weather.TOT_RADIATION_SOLAR_TOTAL_WPM2,
    weather.CITY,
    weather.STATE,
    weather.STATEABRV
FROM weather WHERE rownum = 1;
