/*=============================================
Title: createrole_covid

Usage: 

Author:		Rice, Newel

--
Create date: 2020-OCT-17
--
Description:	createrole_covid
				is used to setup a role
                for access to the shared covid data

Requires:	none
--
--
Optional:
--
WARNING: This is a destructive script - review before using - USE AT YOUR OWN RISK!
--
Copyright (C) 2020 - Sirius Solutions, Inc.
All Rights Reserved
--
Version: 0.0.1.000
Revision History:


0.0.1.000 Original
=============================================*/
--Setup the context
USE ROLE ACCOUNTADMIN;

--create covid role
CREATE ROLE "COVID";
GRANT ROLE "COVID" TO ROLE "SYSADMIN";