/*=============================================
Title: source_coviddata

Usage: 

Author:		Rice, Newel

--
Create date: 2020-OCT-17
--
Description:	source_coviddata
				is used to setup covid data for the Lab/Demo environment

Requires:	none
--
--
Optional:
--
WARNING: This is a destructive script - review before using - USE AT YOUR OWN RISK!
--
Copyright (C) 2020 - Sirius Solutions, Inc.
All Rights Reserved
--
Version: 0.0.1.000
Revision History:


0.0.1.000 Original
=============================================*/
--Setup the context
USE ROLE SYSADMIN;
USE WAREHOUSE XSMALL;
USE ID_DEV;
USE SCHEMA public;

--Where are we getting out COVID daata from? The Data Market Place/
CREATE OR REPLACE TABLE PUBLIC.CT_US_COVID_TESTS AS SELECT * FROM "STARSCHEMA_AZURE_US_WEST_COVID19_BY_STARSCHEMA_DM"."PUBLIC"."CT_US_COVID_TESTS";