/*=============================================
Title: ServiceUserIDandWarehouseSetup

Usage: 

Author:		Rice, Newel

--
Create date: 2020-OCT-17
--
Description:	ServiceUserIDandWarehouseSetup
				is used to setup service user IDs,
                the database to work from
				and warehouses for the Lab/Demo environment

Requires:	none
--
--
Optional:
--
WARNING: This is a destructive script - review before using - USE AT YOUR OWN RISK!
--
Copyright (C) 2020 - Sirius Solutions, Inc.
All Rights Reserved
--
Version: 0.0.1.000
Revision History:


0.0.1.000 Original
=============================================*/
--Setup the context
USE ROLE ACCOUNTADMIN;

--create a database to put all of our data in
CREATE DATABASE IF NOT EXISTS ID_DEV;

--set ownership of the new database to SYSADMIN
GRANT OWNERSHIP ON DATABASE "ID_DEV" TO ROLE "SYSADMIN";

-- create public schema
CREATE OR REPLACE SCHEMA ID_DEV.PUBLIC;

-- set ownership of the new PUBLIC schema to SYSADMIN
GRANT OWNERSHIP ON SCHEMA "ID_DEV"."PUBLIC" TO ROLE "SYSADMIN";

--create warehouse
CREATE
WAREHOUSE IF NOT EXISTS XSMALL 
WITH
WAREHOUSE_SIZE = 'XSMALL' 
WAREHOUSE_TYPE = 'STANDARD'
AUTO_SUSPEND = 300
AUTO_RESUME = TRUE
MIN_CLUSTER_COUNT = 1
MAX_CLUSTER_COUNT = 1 
SCALING_POLICY = 'STANDARD' 
COMMENT = 'XSMALL Demo Warehouse';

--set ownership of the new XSMALL warehouse to SYSADMIN
GRANT OWNERSHIP ON WAREHOUSE "XSMALL" TO ROLE "SYSADMIN";

--create user ID
CREATE
USER SVC_TRX
PASSWORD = '{password}' 
LOGIN_NAME = 'SVC_TRX' 
DISPLAY_NAME = 'Service TRX' 
FIRST_NAME = 'Service'
LAST_NAME = 'TRX'
EMAIL = '{AAA@AAA.AAA}'
COMMENT = 'Service Account'
DEFAULT_ROLE = 'SYSADMIN' 
DEFAULT_WAREHOUSE = 'XSMALL' 
MUST_CHANGE_PASSWORD = FALSE;

-- grant role
GRANT ROLE "SYSADMIN" TO USER SVC_TRX;

--create user ID
CREATE
USER SVC_DATA
PASSWORD = '{password}' 
LOGIN_NAME = 'SVC_DATA' 
DISPLAY_NAME = 'Service DATA' 
FIRST_NAME = 'Service'
LAST_NAME = 'DATA'
EMAIL = '{AAA@AAA.AAA}'
COMMENT = 'Service Account'
DEFAULT_ROLE = 'SYSADMIN' 
DEFAULT_WAREHOUSE = 'XSMALL' 
MUST_CHANGE_PASSWORD = FALSE;

-- grant role
GRANT ROLE "SYSADMIN" TO USER SVC_DATA;